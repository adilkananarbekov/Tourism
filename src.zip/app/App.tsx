import { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { ToursGrid } from './components/ToursGrid';
import { TourDetail } from './components/TourDetail';
import { CustomTourForm } from './components/CustomTourForm';
import { Footer } from './components/Footer';
import { Features } from './components/Features';
import { Testimonials } from './components/Testimonials';
import { CTA } from './components/CTA';

type Page = 'home' | 'tours' | 'tour-detail' | 'custom-tour' | 'sights' | 'stories' | 'about' | 'blogs';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [selectedTourId, setSelectedTourId] = useState<number | null>(null);

  const handleNavigate = (page: string) => {
    setCurrentPage(page as Page);
    setSelectedTourId(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleTourSelect = (tourId: number) => {
    setSelectedTourId(tourId);
    setCurrentPage('tour-detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToTours = () => {
    setCurrentPage('tours');
    setSelectedTourId(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToHome = () => {
    setCurrentPage('home');
    setSelectedTourId(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header currentPage={currentPage} onNavigate={handleNavigate} />
      
      <main className="flex-1">
        {/* Home Page */}
        {currentPage === 'home' && (
          <>
            <Hero onNavigate={handleNavigate} />
            <Features />
            <ToursGrid onTourSelect={handleTourSelect} />
            <Testimonials />
            <CTA onNavigate={handleNavigate} />
          </>
        )}

        {/* Tours Listing */}
        {currentPage === 'tours' && (
          <ToursGrid onTourSelect={handleTourSelect} />
        )}

        {/* Tour Detail */}
        {currentPage === 'tour-detail' && selectedTourId && (
          <TourDetail tourId={selectedTourId} onBack={handleBackToTours} />
        )}

        {/* Custom Tour Form */}
        {currentPage === 'custom-tour' && (
          <CustomTourForm onBack={handleBackToHome} />
        )}

        {/* Placeholder pages for other sections */}
        {currentPage === 'sights' && (
          <div className="py-16 px-4 text-center bg-gray-50 min-h-[600px] flex items-center justify-center">
            <div className="max-w-2xl mx-auto">
              <h2 className="text-4xl text-gray-900 mb-4">Sights & Destinations</h2>
              <p className="text-xl text-gray-600">
                Explore the most spectacular sights in Kyrgyzstan. This section is coming soon!
              </p>
            </div>
          </div>
        )}

        {currentPage === 'stories' && (
          <div className="py-16 px-4 text-center bg-gray-50 min-h-[600px] flex items-center justify-center">
            <div className="max-w-2xl mx-auto">
              <h2 className="text-4xl text-gray-900 mb-4">Travel Stories</h2>
              <p className="text-xl text-gray-600">
                Read inspiring stories from travelers who explored Kyrgyzstan with us. Coming soon!
              </p>
            </div>
          </div>
        )}

        {currentPage === 'about' && (
          <div className="py-16 px-4 bg-gray-50 min-h-[600px]">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-4xl text-gray-900 mb-8 text-center">About Kyrgyz Riders</h2>
              <div className="bg-white rounded-lg p-8 shadow-md space-y-6">
                <p className="text-lg text-gray-600 leading-relaxed">
                  Kyrgyz Riders is a locally-owned adventure travel company specializing in authentic, 
                  sustainable tourism experiences across Kyrgyzstan. Founded by passionate locals who 
                  grew up in these mountains, we bring you closer to the heart of Central Asian culture 
                  and nature.
                </p>
                <p className="text-lg text-gray-600 leading-relaxed">
                  We believe in responsible tourism that benefits local communities while preserving 
                  the pristine beauty of our homeland. Our experienced guides are not just experts in 
                  mountaineering and trekking – they're storytellers, cultural ambassadors, and friends 
                  who will share the true spirit of Kyrgyzstan with you.
                </p>
                <p className="text-lg text-gray-600 leading-relaxed">
                  Whether you're seeking adventure on horseback, cultural immersion in nomadic traditions, 
                  or challenging mountain treks, we create unforgettable journeys tailored to your dreams.
                </p>
              </div>
            </div>
          </div>
        )}

        {currentPage === 'blogs' && (
          <div className="py-16 px-4 text-center bg-gray-50 min-h-[600px] flex items-center justify-center">
            <div className="max-w-2xl mx-auto">
              <h2 className="text-4xl text-gray-900 mb-4">Travel Blog</h2>
              <p className="text-xl text-gray-600">
                Discover tips, guides, and insights for traveling in Kyrgyzstan. Coming soon!
              </p>
            </div>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}