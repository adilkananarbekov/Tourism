import { ArrowLeft, Calendar, Check, MapPin, Tag, Users } from 'lucide-react';
import { useState } from 'react';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from './ui/accordion';
import { tours, Tour } from './tour-data';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';

interface TourDetailProps {
  tourId: number;
  onBack: () => void;
}

export function TourDetail({ tourId, onBack }: TourDetailProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [showBookingForm, setShowBookingForm] = useState(false);
  
  const tour = tours.find((t) => t.id === tourId);

  if (!tour) {
    return (
      <div className="py-16 px-4 text-center">
        <p>Tour not found</p>
        <Button onClick={onBack} className="mt-4">
          Back to Tours
        </Button>
      </div>
    );
  }

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <div className="relative h-[400px] md:h-[500px]">
        <img
          src={tour.image}
          alt={tour.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40" />
        <div className="absolute inset-0 flex items-center">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
            <Button
              onClick={onBack}
              variant="outline"
              className="mb-6 bg-white/10 hover:bg-white/20 text-white border-white backdrop-blur-sm"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Tours
            </Button>
            <h1 className="text-4xl md:text-5xl lg:text-6xl text-white mb-4">
              {tour.title}
            </h1>
            <div className="flex flex-wrap gap-6 text-white text-lg">
              <div className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                <span>{tour.duration}</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                <span>{tour.tourType}</span>
              </div>
              <div className="flex items-center gap-2">
                <Tag className="h-5 w-5" />
                <span>{tour.price}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Desktop Tabs */}
            <div className="hidden md:block">
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-5 mb-8">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="itinerary">Itinerary</TabsTrigger>
                  <TabsTrigger value="highlights">Highlights</TabsTrigger>
                  <TabsTrigger value="packing">Packing</TabsTrigger>
                  <TabsTrigger value="info">Practical Info</TabsTrigger>
                </TabsList>

                <TabsContent value="overview">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-2xl text-gray-900 mb-4">About This Tour</h3>
                      <p className="text-gray-600 text-lg leading-relaxed">
                        {tour.description}
                      </p>
                    </div>
                    <div>
                      <h4 className="text-xl text-gray-900 mb-3">Tour Details</h4>
                      <div className="grid grid-cols-2 gap-4 text-gray-600">
                        <div>
                          <p className="text-sm text-gray-500">Duration</p>
                          <p>{tour.duration}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-500">Season</p>
                          <p>{tour.season}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-500">Tour Type</p>
                          <p>{tour.tourType}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-500">Difficulty</p>
                          <p>{tour.practicalInfo.difficulty}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="itinerary">
                  <h3 className="text-2xl text-gray-900 mb-6">Day by Day Itinerary</h3>
                  <div className="space-y-6">
                    {tour.itinerary.map((day) => (
                      <div key={day.day} className="border-l-4 border-blue-600 pl-6 pb-6">
                        <h4 className="text-lg text-gray-900 mb-2">
                          Day {day.day}: {day.title}
                        </h4>
                        <p className="text-gray-600">{day.description}</p>
                      </div>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="highlights">
                  <h3 className="text-2xl text-gray-900 mb-6">Tour Highlights</h3>
                  <ul className="space-y-4">
                    {tour.highlights.map((highlight, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <Check className="h-6 w-6 text-blue-600 flex-shrink-0 mt-1" />
                        <span className="text-gray-600 text-lg">{highlight}</span>
                      </li>
                    ))}
                  </ul>
                </TabsContent>

                <TabsContent value="packing">
                  <h3 className="text-2xl text-gray-900 mb-6">What to Pack</h3>
                  <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {tour.packingList.map((item, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <Check className="h-5 w-5 text-blue-600 flex-shrink-0 mt-1" />
                        <span className="text-gray-600">{item}</span>
                      </li>
                    ))}
                  </ul>
                </TabsContent>

                <TabsContent value="info">
                  <h3 className="text-2xl text-gray-900 mb-6">Practical Information</h3>
                  <div className="space-y-6">
                    <div>
                      <h4 className="text-lg text-gray-900 mb-2">Accommodation</h4>
                      <p className="text-gray-600">{tour.practicalInfo.accommodation}</p>
                    </div>
                    <div>
                      <h4 className="text-lg text-gray-900 mb-2">Meals</h4>
                      <p className="text-gray-600">{tour.practicalInfo.meals}</p>
                    </div>
                    <div>
                      <h4 className="text-lg text-gray-900 mb-2">Group Size</h4>
                      <p className="text-gray-600">{tour.practicalInfo.groupSize}</p>
                    </div>
                    <div>
                      <h4 className="text-lg text-gray-900 mb-2">What's Included</h4>
                      <ul className="space-y-2">
                        {tour.practicalInfo.included.map((item, index) => (
                          <li key={index} className="flex items-start gap-2 text-gray-600">
                            <Check className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                            {item}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <h4 className="text-lg text-gray-900 mb-2">Not Included</h4>
                      <ul className="space-y-2">
                        {tour.practicalInfo.notIncluded.map((item, index) => (
                          <li key={index} className="text-gray-600">
                            • {item}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>

            {/* Mobile Accordion */}
            <div className="md:hidden">
              <Accordion type="single" collapsible>
                <AccordionItem value="overview">
                  <AccordionTrigger>Overview</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-6">
                      <div>
                        <h3 className="text-xl text-gray-900 mb-3">About This Tour</h3>
                        <p className="text-gray-600 leading-relaxed">
                          {tour.description}
                        </p>
                      </div>
                      <div>
                        <h4 className="text-lg text-gray-900 mb-3">Tour Details</h4>
                        <div className="grid grid-cols-2 gap-4 text-gray-600">
                          <div>
                            <p className="text-sm text-gray-500">Duration</p>
                            <p>{tour.duration}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">Season</p>
                            <p>{tour.season}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">Tour Type</p>
                            <p>{tour.tourType}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">Difficulty</p>
                            <p>{tour.practicalInfo.difficulty}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="itinerary">
                  <AccordionTrigger>Itinerary</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-6">
                      {tour.itinerary.map((day) => (
                        <div key={day.day} className="border-l-4 border-blue-600 pl-4 pb-4">
                          <h4 className="text-gray-900 mb-2">
                            Day {day.day}: {day.title}
                          </h4>
                          <p className="text-gray-600 text-sm">{day.description}</p>
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="highlights">
                  <AccordionTrigger>Highlights</AccordionTrigger>
                  <AccordionContent>
                    <ul className="space-y-3">
                      {tour.highlights.map((highlight, index) => (
                        <li key={index} className="flex items-start gap-3">
                          <Check className="h-5 w-5 text-blue-600 flex-shrink-0 mt-1" />
                          <span className="text-gray-600">{highlight}</span>
                        </li>
                      ))}
                    </ul>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="packing">
                  <AccordionTrigger>Packing List</AccordionTrigger>
                  <AccordionContent>
                    <ul className="space-y-3">
                      {tour.packingList.map((item, index) => (
                        <li key={index} className="flex items-start gap-3">
                          <Check className="h-5 w-5 text-blue-600 flex-shrink-0 mt-1" />
                          <span className="text-gray-600 text-sm">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="info">
                  <AccordionTrigger>Practical Information</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4">
                      <div>
                        <h4 className="text-gray-900 mb-2">Accommodation</h4>
                        <p className="text-gray-600 text-sm">{tour.practicalInfo.accommodation}</p>
                      </div>
                      <div>
                        <h4 className="text-gray-900 mb-2">Meals</h4>
                        <p className="text-gray-600 text-sm">{tour.practicalInfo.meals}</p>
                      </div>
                      <div>
                        <h4 className="text-gray-900 mb-2">Group Size</h4>
                        <p className="text-gray-600 text-sm">{tour.practicalInfo.groupSize}</p>
                      </div>
                      <div>
                        <h4 className="text-gray-900 mb-2">What's Included</h4>
                        <ul className="space-y-2">
                          {tour.practicalInfo.included.map((item, index) => (
                            <li key={index} className="flex items-start gap-2 text-gray-600 text-sm">
                              <Check className="h-4 w-4 text-green-600 flex-shrink-0 mt-0.5" />
                              {item}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <h4 className="text-gray-900 mb-2">Not Included</h4>
                        <ul className="space-y-2 text-gray-600 text-sm">
                          {tour.practicalInfo.notIncluded.map((item, index) => (
                            <li key={index}>• {item}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-gray-50 rounded-lg p-6 sticky top-24">
              <div className="mb-6">
                <p className="text-sm text-gray-600 mb-2">Starting from</p>
                <p className="text-4xl text-gray-900">{tour.price}</p>
                <p className="text-sm text-gray-600">per person</p>
              </div>

              {!showBookingForm ? (
                <Button
                  onClick={() => setShowBookingForm(true)}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white mb-4"
                >
                  Book This Tour
                </Button>
              ) : (
                <BookingForm tour={tour} onCancel={() => setShowBookingForm(false)} />
              )}

              <div className="border-t border-gray-200 pt-6 mt-6 space-y-4">
                <div className="flex items-start gap-3">
                  <Users className="h-5 w-5 text-blue-600 flex-shrink-0 mt-1" />
                  <div>
                    <p className="text-sm text-gray-900">Group Size</p>
                    <p className="text-sm text-gray-600">{tour.practicalInfo.groupSize}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Calendar className="h-5 w-5 text-blue-600 flex-shrink-0 mt-1" />
                  <div>
                    <p className="text-sm text-gray-900">Best Season</p>
                    <p className="text-sm text-gray-600">{tour.season}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <MapPin className="h-5 w-5 text-blue-600 flex-shrink-0 mt-1" />
                  <div>
                    <p className="text-sm text-gray-900">Difficulty</p>
                    <p className="text-sm text-gray-600">{tour.practicalInfo.difficulty}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function BookingForm({ tour, onCancel }: { tour: Tour; onCancel: () => void }) {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="text-center py-6">
        <Check className="h-12 w-12 text-green-600 mx-auto mb-4" />
        <h4 className="text-lg text-gray-900 mb-2">Booking Request Sent!</h4>
        <p className="text-sm text-gray-600 mb-4">
          We'll contact you within 24 hours to confirm your booking.
        </p>
        <Button onClick={onCancel} variant="outline" size="sm">
          Close
        </Button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="name">Full Name</Label>
        <Input id="name" placeholder="John Doe" required />
      </div>
      <div>
        <Label htmlFor="email">Email</Label>
        <Input id="email" type="email" placeholder="john@example.com" required />
      </div>
      <div>
        <Label htmlFor="phone">Phone Number</Label>
        <Input id="phone" placeholder="+1 234 567 8900" required />
      </div>
      <div>
        <Label htmlFor="date">Preferred Date</Label>
        <Input id="date" type="date" required />
      </div>
      <div>
        <Label htmlFor="guests">Number of Guests</Label>
        <Input id="guests" type="number" min="1" defaultValue="2" required />
      </div>
      <div>
        <Label htmlFor="message">Additional Notes</Label>
        <Textarea
          id="message"
          placeholder="Any special requests or questions..."
          rows={3}
        />
      </div>
      <div className="flex gap-2">
        <Button type="submit" className="flex-1 bg-blue-600 hover:bg-blue-700 text-white">
          Submit Request
        </Button>
        <Button type="button" onClick={onCancel} variant="outline">
          Cancel
        </Button>
      </div>
    </form>
  );
}
