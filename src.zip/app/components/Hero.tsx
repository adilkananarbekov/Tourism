import { Button } from './ui/button';

interface HeroProps {
  onNavigate: (page: string) => void;
}

export function Hero({ onNavigate }: HeroProps) {
  return (
    <section className="relative h-[600px] md:h-[700px] lg:h-[800px] flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1757404789665-97caa8db76e0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxreXJneXpzdGFuJTIwbW91bnRhaW4lMjBsYWtlfGVufDF8fHx8MTc2Njk0NDczN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Kyrgyzstan mountain lake"
          className="w-full h-full object-cover"
        />
        {/* Overlay */}
        <div className="absolute inset-0 bg-black/40" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl text-white mb-6">
          Discover the Heart of Central Asia
        </h1>
        <p className="text-lg sm:text-xl md:text-2xl text-white/90 mb-8 max-w-2xl mx-auto">
          Experience unforgettable adventures through Kyrgyzstan's majestic mountains, pristine lakes, and nomadic culture
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button
            onClick={() => onNavigate('tours')}
            className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg w-full sm:w-auto"
          >
            Find Tours
          </Button>
          <Button
            onClick={() => onNavigate('custom-tour')}
            variant="outline"
            className="bg-white/10 hover:bg-white/20 text-white border-white hover:border-white px-8 py-6 text-lg backdrop-blur-sm w-full sm:w-auto"
          >
            Create Your Tour
          </Button>
        </div>
      </div>
    </section>
  );
}
