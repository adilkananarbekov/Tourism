import { ArrowLeft, ArrowRight, Calendar, Check, MapPin, Users } from 'lucide-react';
import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Checkbox } from './ui/checkbox';

interface CustomTourFormProps {
  onBack: () => void;
}

interface FormData {
  groupSize: string;
  startDate: string;
  endDate: string;
  startLocation: string;
  endLocation: string;
  sights: string[];
  activities: string[];
  pace: string;
  accommodation: string;
  name: string;
  email: string;
  phone: string;
  budget: string;
  specialRequests: string;
}

const INITIAL_FORM_DATA: FormData = {
  groupSize: '',
  startDate: '',
  endDate: '',
  startLocation: 'bishkek',
  endLocation: 'bishkek',
  sights: [],
  activities: [],
  pace: 'moderate',
  accommodation: 'mix',
  name: '',
  email: '',
  phone: '',
  budget: '',
  specialRequests: '',
};

export function CustomTourForm({ onBack }: CustomTourFormProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<FormData>(INITIAL_FORM_DATA);
  const [submitted, setSubmitted] = useState(false);

  const totalSteps = 4;

  const sightsOptions = [
    { id: 'song-kul', label: 'Song-Kul Lake' },
    { id: 'issyk-kul', label: 'Issyk-Kul Lake' },
    { id: 'ala-archa', label: 'Ala-Archa National Park' },
    { id: 'tash-rabat', label: 'Tash Rabat Caravanserai' },
    { id: 'jeti-oguz', label: 'Jeti-Oguz (Seven Bulls)' },
    { id: 'skazka', label: 'Skazka Canyon' },
    { id: 'burana', label: 'Burana Tower' },
    { id: 'osh', label: 'Osh & Solomon\'s Throne' },
  ];

  const activitiesOptions = [
    { id: 'trekking', label: 'Trekking & Hiking' },
    { id: 'horse-riding', label: 'Horse Riding' },
    { id: 'yurt-stay', label: 'Yurt Stay Experience' },
    { id: 'cultural', label: 'Cultural Activities' },
    { id: 'wildlife', label: 'Wildlife Watching' },
    { id: 'photography', label: 'Photography Tours' },
    { id: 'mountaineering', label: 'Mountaineering' },
    { id: 'cycling', label: 'Mountain Biking' },
  ];

  const handleSightToggle = (sightId: string) => {
    setFormData((prev) => ({
      ...prev,
      sights: prev.sights.includes(sightId)
        ? prev.sights.filter((id) => id !== sightId)
        : [...prev.sights, sightId],
    }));
  };

  const handleActivityToggle = (activityId: string) => {
    setFormData((prev) => ({
      ...prev,
      activities: prev.activities.includes(activityId)
        ? prev.activities.filter((id) => id !== activityId)
        : [...prev.activities, activityId],
    }));
  };

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = () => {
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-gray-50 py-12 px-4">
        <div className="max-w-2xl mx-auto">
          <div className="bg-white rounded-lg shadow-md p-8 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Check className="h-8 w-8 text-green-600" />
            </div>
            <h2 className="text-3xl text-gray-900 mb-4">
              Custom Tour Request Submitted!
            </h2>
            <p className="text-lg text-gray-600 mb-8">
              Thank you for your interest in creating a custom tour. Our team will review your
              requirements and get back to you within 24-48 hours with a personalized itinerary
              and pricing.
            </p>
            <div className="bg-blue-50 rounded-lg p-6 mb-8 text-left">
              <h3 className="text-lg text-gray-900 mb-4">What happens next?</h3>
              <ul className="space-y-3 text-gray-600">
                <li className="flex items-start gap-3">
                  <Check className="h-5 w-5 text-blue-600 flex-shrink-0 mt-1" />
                  <span>Our tour specialists will design a custom itinerary based on your preferences</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="h-5 w-5 text-blue-600 flex-shrink-0 mt-1" />
                  <span>We'll send you a detailed proposal with day-by-day activities and pricing</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="h-5 w-5 text-blue-600 flex-shrink-0 mt-1" />
                  <span>You can request modifications until the itinerary perfectly fits your needs</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="h-5 w-5 text-blue-600 flex-shrink-0 mt-1" />
                  <span>Once confirmed, we'll handle all bookings and logistics</span>
                </li>
              </ul>
            </div>
            <Button
              onClick={onBack}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              Return to Home
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <Button
            onClick={onBack}
            variant="outline"
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Tours
          </Button>
          <h1 className="text-4xl text-gray-900 mb-4">
            Create Your Custom Tour
          </h1>
          <p className="text-xl text-gray-600">
            Design your perfect adventure in Kyrgyzstan with our help
          </p>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            {[1, 2, 3, 4].map((step) => (
              <div key={step} className="flex items-center flex-1">
                <div
                  className={`flex items-center justify-center w-10 h-10 rounded-full ${
                    currentStep >= step
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-200 text-gray-500'
                  }`}
                >
                  {step}
                </div>
                {step < 4 && (
                  <div
                    className={`flex-1 h-1 mx-2 ${
                      currentStep > step ? 'bg-blue-600' : 'bg-gray-200'
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between text-sm text-gray-600">
            <span>Basics</span>
            <span>Destinations</span>
            <span>Preferences</span>
            <span>Contact</span>
          </div>
        </div>

        {/* Form */}
        <div className="bg-white rounded-lg shadow-md p-8">
          {/* Step 1: Basic Information */}
          {currentStep === 1 && (
            <div className="space-y-6">
              <h2 className="text-2xl text-gray-900 mb-6">Basic Information</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="groupSize">
                    <Users className="h-4 w-4 inline mr-2" />
                    Group Size
                  </Label>
                  <Input
                    id="groupSize"
                    type="number"
                    min="1"
                    placeholder="e.g., 4"
                    value={formData.groupSize}
                    onChange={(e) =>
                      setFormData({ ...formData, groupSize: e.target.value })
                    }
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="budget">Approximate Budget (USD)</Label>
                  <Input
                    id="budget"
                    placeholder="e.g., $2000 per person"
                    value={formData.budget}
                    onChange={(e) =>
                      setFormData({ ...formData, budget: e.target.value })
                    }
                  />
                </div>

                <div>
                  <Label htmlFor="startDate">
                    <Calendar className="h-4 w-4 inline mr-2" />
                    Start Date
                  </Label>
                  <Input
                    id="startDate"
                    type="date"
                    value={formData.startDate}
                    onChange={(e) =>
                      setFormData({ ...formData, startDate: e.target.value })
                    }
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="endDate">
                    <Calendar className="h-4 w-4 inline mr-2" />
                    End Date
                  </Label>
                  <Input
                    id="endDate"
                    type="date"
                    value={formData.endDate}
                    onChange={(e) =>
                      setFormData({ ...formData, endDate: e.target.value })
                    }
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="startLocation">
                    <MapPin className="h-4 w-4 inline mr-2" />
                    Starting Location
                  </Label>
                  <select
                    id="startLocation"
                    className="w-full h-10 px-3 rounded-md border border-gray-300 bg-white text-sm"
                    value={formData.startLocation}
                    onChange={(e) =>
                      setFormData({ ...formData, startLocation: e.target.value })
                    }
                  >
                    <option value="bishkek">Bishkek</option>
                    <option value="osh">Osh</option>
                    <option value="karakol">Karakol</option>
                  </select>
                </div>

                <div>
                  <Label htmlFor="endLocation">
                    <MapPin className="h-4 w-4 inline mr-2" />
                    Ending Location
                  </Label>
                  <select
                    id="endLocation"
                    className="w-full h-10 px-3 rounded-md border border-gray-300 bg-white text-sm"
                    value={formData.endLocation}
                    onChange={(e) =>
                      setFormData({ ...formData, endLocation: e.target.value })
                    }
                  >
                    <option value="bishkek">Bishkek</option>
                    <option value="osh">Osh</option>
                    <option value="karakol">Karakol</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* Step 2: Destinations & Sights */}
          {currentStep === 2 && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl text-gray-900 mb-2">Destinations & Sights</h2>
                <p className="text-gray-600 mb-6">Select the places you'd like to visit</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {sightsOptions.map((sight) => (
                  <div
                    key={sight.id}
                    className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                      formData.sights.includes(sight.id)
                        ? 'border-blue-600 bg-blue-50'
                        : 'border-gray-200 hover:border-blue-300'
                    }`}
                    onClick={() => handleSightToggle(sight.id)}
                  >
                    <div className="flex items-center gap-3">
                      <Checkbox
                        checked={formData.sights.includes(sight.id)}
                        onCheckedChange={() => handleSightToggle(sight.id)}
                      />
                      <label className="cursor-pointer flex-1">{sight.label}</label>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Step 3: Activities & Preferences */}
          {currentStep === 3 && (
            <div className="space-y-8">
              <div>
                <h2 className="text-2xl text-gray-900 mb-2">Activities & Preferences</h2>
                <p className="text-gray-600 mb-6">
                  Choose your preferred activities and tour style
                </p>
              </div>

              <div>
                <h3 className="text-lg text-gray-900 mb-4">Desired Activities</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {activitiesOptions.map((activity) => (
                    <div
                      key={activity.id}
                      className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                        formData.activities.includes(activity.id)
                          ? 'border-blue-600 bg-blue-50'
                          : 'border-gray-200 hover:border-blue-300'
                      }`}
                      onClick={() => handleActivityToggle(activity.id)}
                    >
                      <div className="flex items-center gap-3">
                        <Checkbox
                          checked={formData.activities.includes(activity.id)}
                          onCheckedChange={() => handleActivityToggle(activity.id)}
                        />
                        <label className="cursor-pointer flex-1">{activity.label}</label>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-lg text-gray-900 mb-4">Tour Pace</h3>
                <RadioGroup
                  value={formData.pace}
                  onValueChange={(value) => setFormData({ ...formData, pace: value })}
                >
                  <div className="space-y-3">
                    <div className="flex items-start gap-3 p-4 border rounded-lg">
                      <RadioGroupItem value="relaxed" id="relaxed" />
                      <div className="flex-1">
                        <Label htmlFor="relaxed" className="cursor-pointer">
                          Relaxed
                        </Label>
                        <p className="text-sm text-gray-600">
                          Easy pace with plenty of rest time and flexibility
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-4 border rounded-lg">
                      <RadioGroupItem value="moderate" id="moderate" />
                      <div className="flex-1">
                        <Label htmlFor="moderate" className="cursor-pointer">
                          Moderate
                        </Label>
                        <p className="text-sm text-gray-600">
                          Balanced pace with mix of activities and rest
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-4 border rounded-lg">
                      <RadioGroupItem value="active" id="active" />
                      <div className="flex-1">
                        <Label htmlFor="active" className="cursor-pointer">
                          Active
                        </Label>
                        <p className="text-sm text-gray-600">
                          Fast-paced with maximum activities and sights
                        </p>
                      </div>
                    </div>
                  </div>
                </RadioGroup>
              </div>

              <div>
                <h3 className="text-lg text-gray-900 mb-4">Accommodation Type</h3>
                <RadioGroup
                  value={formData.accommodation}
                  onValueChange={(value) =>
                    setFormData({ ...formData, accommodation: value })
                  }
                >
                  <div className="space-y-3">
                    <div className="flex items-start gap-3 p-4 border rounded-lg">
                      <RadioGroupItem value="hotels" id="hotels" />
                      <div className="flex-1">
                        <Label htmlFor="hotels" className="cursor-pointer">
                          Hotels & Guesthouses
                        </Label>
                        <p className="text-sm text-gray-600">
                          Comfortable hotels and local guesthouses
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-4 border rounded-lg">
                      <RadioGroupItem value="mix" id="mix" />
                      <div className="flex-1">
                        <Label htmlFor="mix" className="cursor-pointer">
                          Mix (Hotels + Yurts)
                        </Label>
                        <p className="text-sm text-gray-600">
                          Combination of hotels and traditional yurt stays
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-4 border rounded-lg">
                      <RadioGroupItem value="camping" id="camping" />
                      <div className="flex-1">
                        <Label htmlFor="camping" className="cursor-pointer">
                          Camping & Yurts
                        </Label>
                        <p className="text-sm text-gray-600">
                          Authentic outdoor experience with camping and yurts
                        </p>
                      </div>
                    </div>
                  </div>
                </RadioGroup>
              </div>
            </div>
          )}

          {/* Step 4: Contact Information */}
          {currentStep === 4 && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl text-gray-900 mb-2">Contact Information</h2>
                <p className="text-gray-600 mb-6">
                  Let us know how to reach you with your custom itinerary
                </p>
              </div>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Full Name *</Label>
                  <Input
                    id="name"
                    placeholder="John Doe"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="email">Email Address *</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="john@example.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input
                    id="phone"
                    placeholder="+1 234 567 8900"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="specialRequests">
                    Special Requests or Additional Information
                  </Label>
                  <Textarea
                    id="specialRequests"
                    placeholder="Any dietary restrictions, accessibility needs, or special interests..."
                    rows={5}
                    value={formData.specialRequests}
                    onChange={(e) =>
                      setFormData({ ...formData, specialRequests: e.target.value })
                    }
                  />
                </div>
              </div>

              <div className="bg-blue-50 rounded-lg p-6 mt-6">
                <h3 className="text-lg text-gray-900 mb-3">Tour Summary</h3>
                <div className="space-y-2 text-sm text-gray-600">
                  <p>
                    <strong>Group Size:</strong> {formData.groupSize || 'Not specified'} people
                  </p>
                  <p>
                    <strong>Dates:</strong> {formData.startDate || 'Not specified'} to{' '}
                    {formData.endDate || 'Not specified'}
                  </p>
                  <p>
                    <strong>Route:</strong> {formData.startLocation} to {formData.endLocation}
                  </p>
                  <p>
                    <strong>Selected Sights:</strong>{' '}
                    {formData.sights.length > 0
                      ? `${formData.sights.length} locations`
                      : 'None selected'}
                  </p>
                  <p>
                    <strong>Activities:</strong>{' '}
                    {formData.activities.length > 0
                      ? `${formData.activities.length} activities`
                      : 'None selected'}
                  </p>
                  <p>
                    <strong>Pace:</strong> {formData.pace}
                  </p>
                  <p>
                    <strong>Accommodation:</strong> {formData.accommodation}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex gap-4 mt-8 pt-8 border-t">
            {currentStep > 1 && (
              <Button onClick={handleBack} variant="outline" className="flex-1">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Previous
              </Button>
            )}
            {currentStep < totalSteps ? (
              <Button
                onClick={handleNext}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
              >
                Next
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            ) : (
              <Button
                onClick={handleSubmit}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
              >
                Submit Request
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
