import { Calendar, MapPin, Tag } from 'lucide-react';
import { Button } from './ui/button';
import { tours } from './tour-data';

interface ToursGridProps {
  onTourSelect: (tourId: number) => void;
}

export function ToursGrid({ onTourSelect }: ToursGridProps) {
  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl text-gray-900 mb-4">
            Our Adventure Tours
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Choose from our carefully curated selection of tours, each designed to showcase the best of Kyrgyzstan's natural beauty and cultural heritage
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {tours.map((tour) => (
            <div
              key={tour.id}
              className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow duration-300"
            >
              {/* Tour Image */}
              <div className="relative h-64 overflow-hidden">
                <img
                  src={tour.image}
                  alt={tour.title}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 right-4">
                  <span className="inline-flex items-center px-3 py-1 rounded-full bg-blue-600 text-white">
                    {tour.season}
                  </span>
                </div>
              </div>

              {/* Tour Content */}
              <div className="p-6">
                <h3 className="text-2xl text-gray-900 mb-3">
                  {tour.title}
                </h3>

                <div className="flex flex-wrap gap-4 mb-4 text-sm text-gray-600">
                  <div className="flex items-center gap-1">
                    <Calendar className="h-4 w-4" />
                    <span>{tour.duration}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <MapPin className="h-4 w-4" />
                    <span>{tour.tourType}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Tag className="h-4 w-4" />
                    <span>{tour.price}</span>
                  </div>
                </div>

                <p className="text-gray-600 mb-6 line-clamp-3">
                  {tour.description}
                </p>

                <Button
                  onClick={() => onTourSelect(tour.id)}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                >
                  View Details
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
